/* Stub for IPAddress.cpp */

#include <IPAddress.cpp>